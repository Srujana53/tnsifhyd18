package STREAMAPI;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> number = Arrays.asList(2, 3, 4, 5); 

//map       
        List<Integer> square 
          = number.stream()
            .map(x -> x * x)
            .collect(Collectors.toList());
        System.out.println(square);
//filter
       
        List<String> names = Arrays.asList(
            "Reflection", "Collection", "Stream");

        // demonstration of filter method
        List<String> result
          = names.stream()
            .filter(s -> s.startsWith("S"))
            .collect(Collectors.toList());
      
        System.out.println(result);

   //sort     
        List<String> show 
          = names.stream()
            .sorted()
            .collect(Collectors.toList());
      
        System.out.println(show);
        

       //skip
        List<Integer> numbers
            = Arrays.asList(2, 3, 4, 5, 2);

        
        Set<Integer> squareSet
          = numbers.stream()
            .skip(2)
            .collect(Collectors.toSet());
      
        System.out.println(squareSet);
//limit
        // demonstration of forEach method
        number.stream()
            .limit(2)
            .forEach(y -> System.out.println(y));
        

   //reduce  
        int even 
          = number.stream()
            .filter(x -> x % 2 == 0)
            .reduce(0, (ans, i) -> ans + i);

        System.out.println(even);
        
        
        
        
    }


	}



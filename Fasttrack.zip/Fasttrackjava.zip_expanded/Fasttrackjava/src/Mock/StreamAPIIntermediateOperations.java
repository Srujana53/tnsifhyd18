package Mock;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamAPIIntermediateOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> li=Arrays.asList(1,5,6,7,8);
		Stream<Integer> data=li.stream();
		/*Stream<Integer> sorteddata=data.sorted();
		sorteddata.forEach(n->System.out.println(n));
		Stream<Integer> mapdata=data.map(n->(n*2));
		mapdata.forEach(n->System.out.println(n));
		Stream<Integer> filterdata=data.filter(n->(n%2==0));
		filterdata.forEach(n->System.out.println(n));
		Stream<Integer> distinctdata=data.distinct();
		distinctdata.forEach(n->System.out.println(n));
		 data.limit(2)
         .forEach( n -> { System.out.println(n); });*/
		 data.skip(2)
		 .forEach(n->{System.out.println(n);});
		 
		
		
		
	
		
		
		
		

		
		
		
		
		

	}

}

package Mock;

public class InvalidAgeException extends Exception{
	public InvalidAgeException(String str)
	{
		super(str);
	}

}


package Mock;

public interface InterfaceLion {
	void roar();

}

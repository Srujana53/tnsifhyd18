package com.day1;

public class NormalClass {
	
	int a =10; //instance variable
	static int b=20; //static variable
	
	
	//instance method
	public void display() {
		System.out.println("Hello Display");
	}
	
	//static method
	public static void display1() {
		System.out.println("Hello static display");
	}

}

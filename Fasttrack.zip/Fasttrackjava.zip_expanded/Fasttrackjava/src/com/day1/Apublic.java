package com.day1;

public class Apublic {
	public void display()
	{
	System.out.print("This is public method");
	}

}

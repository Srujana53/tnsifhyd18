package com.day1;

public class Bpublic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Apublic obj=new Apublic();
		obj.display();
		
	}

}

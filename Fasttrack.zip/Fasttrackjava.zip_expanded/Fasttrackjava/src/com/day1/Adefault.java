package com.day1;

public class Adefault {
   void display()
	{
	System.out.print("This is default method");
	}

}

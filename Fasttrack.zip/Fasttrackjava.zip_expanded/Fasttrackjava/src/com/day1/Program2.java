package com.day1;

import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	   Scanner sc= new Scanner(System.in);
	   System.out.print("Enter a number:");
	   
	   int n=sc.nextInt();
		if(n%2==0)
		{
			System.out.print("The number " + n + " is Even");
		}
		else
		{
			System.out.print("The number" + n +" is Odd");
		}

	}

}

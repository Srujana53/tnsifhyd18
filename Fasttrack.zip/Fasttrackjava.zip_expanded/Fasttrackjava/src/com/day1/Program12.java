package com.day1;

import java.util.Scanner;

public class Program12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first string:");
		String str1=sc.nextLine();
		System.out.println("enter second string:");
		String str2=sc.nextLine();
		String concatstr=str1+str2;
		System.out.println("The concatenated Strings are:" +concatstr);
		sc.close();

	}

}

package com.day1;

public class Bprivate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aprivate obj=new Aprivate();
		obj.display();
		

	}

}

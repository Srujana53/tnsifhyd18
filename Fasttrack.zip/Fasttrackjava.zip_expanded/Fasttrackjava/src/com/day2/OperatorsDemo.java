package com.day2;

public class OperatorsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20;
		//Arithmetic
		System.out.println("Addition:" +(a+b));
		System.out.println("Subtraction:" +(a-b));       
		System.out.println("Multiplication: " +(a*b));
		System.out.println("Division :" +(a/b));
		System.out.println("Modulus: " +(a%b)); 
		//Assignment
		System.out.println(" c value is : " +(a+=2));
		System.out.println(" d value is : " +(a-=2));
		System.out.println(" e value is : " +(a*=2));
		//Unary Operator
		int x=60;
		System.out.println(x++);
		System.out.println(++x);
		System.out.println(--x);
		System.out.println(x--);
		//Ternary operator
		int y=(10==9)?1:0;
		System.out.println(" y value is:" +y);
		//relational 
		if(x>0)
		{
			System.out.println(" positive number");
			
		}
		else
		{
			System.out.println(" Negative number");
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		


	}

}

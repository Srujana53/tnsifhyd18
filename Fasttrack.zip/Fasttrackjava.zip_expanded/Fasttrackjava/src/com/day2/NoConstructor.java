package com.day2;

public class NoConstructor {
	
	private String brand = "samsung";
	
	public String getBrand() {
		return brand;
	}

}

package com.day2;

public class DerivedOveriding extends BaseOverriding{
	void display()
	{
		System.out.println("Derived class instance method");
		
		}
	
   static void show()
   {
	   System.out.println("Derived class static method ");
   }
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method 
		BaseOverriding obj=new DerivedOveriding();
		obj.show();
		obj.display();
		

	} 

}

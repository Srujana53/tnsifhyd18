package com.day2;
import java.util.*;

public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter integer value:");
		int a=sc.nextInt();
		System.out.println("Integer value is:" +a);
		System.out.print("Enter float value");
		float b=sc.nextFloat();
		System.out.println("Float value  is:" +b);
		System.out.print("Enter Double value:");
		double c=sc.nextDouble();
		System.out.println("Double value  is:" +c);
		System.out.print("Enter your name: ");
		String name=sc.next();
		System.out.println("Your Name is:" +name);
		
		
		
		
		

	}

}

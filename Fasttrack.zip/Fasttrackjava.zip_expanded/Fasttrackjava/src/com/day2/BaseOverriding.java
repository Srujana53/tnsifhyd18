package com.day2;

public class BaseOverriding {
	
	void display()
	{
		System.out.println("Base class instance method");
		
		}
	
   static void show()
   {
	   System.out.println("Base class static method ");
   }
	
	


}

package com.accessspecifiers;
import com.day1.*;

public class Bdefault {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Adefault obj=new Adefault();
		obj.display();
		

	}

}

package com.day4;

public class AbstractMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractShape s=new Square();
		AbstractShape r=new Rectangle();
		AbstractShape c=new Circle();
		s.area();
		r.area();
		c.area();
		

	}

}

package com.day4;

public class Unboxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer a1=Integer.valueOf(23);
		Double d1=Double.valueOf(4.56);
		Character c1=Character.valueOf('a');
		int a=a1.intValue();
		double b=d1.doubleValue();
		char c=c1.charValue();
		System.out.println("The value of a  is: " +a);
		System.out.println("The value of b is: " +b);
		System.out.println("The value od c is: " +c);


	}

}

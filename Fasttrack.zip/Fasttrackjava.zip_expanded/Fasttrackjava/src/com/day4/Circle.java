package com.day4;

public class Circle extends AbstractShape{

	@Override
	void area() {
		// TODO Auto-generated method stub
		double radius=4.5;
		System.out.println("The area of circle is:" +(3.14*radius*radius));
		
	}

}

package com.day4;

public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int arr[][] = {{2,7},{3,1},{1,2}};
	    for (int i=0; i< 3 ; i++)
       	{
           for (int j=0; j < 2; j++)
               System.out.print(arr[i][j] + " ");
           System.out.println();
           
        }
	}
}

package com.day4;

public  abstract class AbstractShape {
	 abstract void area();

}

package com.day4;

public class InterfaceExample implements AInterface{
	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Interface A Implementation");
		
		
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AInterface obj=new InterfaceExample();
		obj.show();

	}

	
}

package com.day4;

public class EmployeeArrayOfObjects {
	int id;
	String name;
	public EmployeeArrayOfObjects(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	

}

package com.day5;

public class ThrowBlock {

	
		// TODO Auto-generated method stub
		void validate(int age)
		{
			if(age>18)
			{
				throw new ArithmeticException("not valid");
			}
			else
			{
				System.out.println("eligible for vote");
			}
		}
		public static void main(String[] args) {
			ThrowBlock b=new ThrowBlock();
			b.validate(19);

	}

}

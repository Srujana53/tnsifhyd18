package com.day5;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPITerminal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> li=Arrays.asList(1,2,32,98,65);
		Stream<Integer> data=li.stream();
		//int sum=data.reduce(0,(c,e)->(c+e));
		//int count=(int) data.count();
		//System.out.println(count);
		int max=data.max(Integer::compare).get();
		System.out.println(max);	
		//data.forEach(n->System.out.println(n));
		
		
		

	}

}

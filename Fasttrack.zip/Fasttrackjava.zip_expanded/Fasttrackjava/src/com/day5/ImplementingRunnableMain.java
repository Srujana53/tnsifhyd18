package com.day5;

public class ImplementingRunnableMain {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int n=5;
		for(int i=0;i<n;i++)
		{
			ImplementingRunnable obj=new ImplementingRunnable();
			Thread t=new Thread(obj);
			t.start();
		}

	}

}

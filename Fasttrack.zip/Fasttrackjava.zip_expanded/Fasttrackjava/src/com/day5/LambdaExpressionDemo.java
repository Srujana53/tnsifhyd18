package com.day5;

public class LambdaExpressionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          FunctionalInterfaceDemo g=()->{
        	  System.out.println("This is Lambda Expression");
          };
          g.show();
	}

}

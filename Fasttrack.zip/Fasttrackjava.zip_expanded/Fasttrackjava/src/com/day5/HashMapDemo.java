package com.day5;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        HashMap<Integer, String> hm=new HashMap<Integer, String>();
        hm.put(1, "Srujana");
        hm.put(2, "Pandu");
        hm.put(3,"sai");
        hm.put(4, "Srujana");
        System.out.println("value at key 1 is: " + hm.get(1));
        for(Map.Entry<Integer,String>e:hm.entrySet())
        {
        	System.out.println(e.getKey() + " " +e.getValue());
        }

	}

}

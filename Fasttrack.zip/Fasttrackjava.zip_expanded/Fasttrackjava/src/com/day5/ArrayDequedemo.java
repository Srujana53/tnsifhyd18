package com.day5;

import java.util.ArrayDeque;

public class ArrayDequedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayDeque<Integer> aq=new ArrayDeque<Integer>();
		aq.add(1);
		aq.add(2);
		aq.add(3);
		aq.add(4);
		System.out.println(aq);
		aq.clear();
		aq.addFirst(10);
		aq.addFirst(20);
		aq.addLast(30);
		aq.addLast(40);
		System.out.println(aq);
	

	}

}

package com.day5;

public class ExtendingThreadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		for(int i=0;i<n;i++)
		{
		ExtendingThread t=new ExtendingThread();
		t.start();
		}

	}

}

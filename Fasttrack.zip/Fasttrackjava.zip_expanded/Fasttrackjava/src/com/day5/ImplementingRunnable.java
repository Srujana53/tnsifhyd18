package com.day5;

public class ImplementingRunnable implements Runnable{
	


	@Override
	public void run() {
		// TODO Auto-generated method stub
		try
		{
			System.out.println("Thread " +Thread.currentThread().getId() + " is running");
		}
		catch(Exception e)
		{
			System.out.println("Exception caught");
		}
		
	}
}

	

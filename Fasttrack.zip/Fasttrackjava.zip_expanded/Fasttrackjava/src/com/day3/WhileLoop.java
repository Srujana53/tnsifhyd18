package com.day3;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=11234,count=0;
		while(n!=0)
		{
			n=n/10;
			count++;
		}
		System.out.print(count);

	}

}

package com.day3;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		do
		{
			System.out.println(i);
			
		}while(i>1);
	}

}

package com.day3;

public class IfElseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		if(a>0)
		{
			System.out.println(" it is positive");
		}
		else
		{
			System.out.println("It is negative");
		}

	}

}

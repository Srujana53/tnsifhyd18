package com.day3;

public class SingleParent {
	void show()
	{
		System.out.println("Parent method");
	}

}

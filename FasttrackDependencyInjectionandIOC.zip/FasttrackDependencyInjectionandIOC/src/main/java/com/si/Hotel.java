package com.si;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Hotel {
	
@Autowired
Customer c;	
@Autowired
Menu m;
@Autowired
Order o;
public void details()
{
	System.out.println("details of Hotel");
	System.out.println(c.bill());
    System.out.println(m.menu());
    System.out.println(o.food());
	
	
}

}

package com.si;

import org.springframework.stereotype.Component;

@Component
public class Order 
{
  public String food()
  {
	  return "Food ordered";
  }
}

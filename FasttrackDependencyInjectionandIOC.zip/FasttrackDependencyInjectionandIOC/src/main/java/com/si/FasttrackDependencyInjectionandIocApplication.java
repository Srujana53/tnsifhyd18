package com.si;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;



@SpringBootApplication
public class FasttrackDependencyInjectionandIocApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(FasttrackDependencyInjectionandIocApplication.class, args);
		Hotel h=context.getBean(Hotel.class);
		h.details();
	}

}

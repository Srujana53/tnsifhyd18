package com.si;

import org.springframework.stereotype.Component;

@Component
public class Customer {

	public String bill()
	{
	   return "customer paid the bill";
	}
}

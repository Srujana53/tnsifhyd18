package com.si;

import org.springframework.stereotype.Component;

@Component
public class Menu 
{
public String menu()
{
	return "Menu details";
}
}

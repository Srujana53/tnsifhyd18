package com.classes;

import com.interfaces.Ipl;

public class Csk implements Ipl{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(" CSK is team of Chennai");
		
	}

}

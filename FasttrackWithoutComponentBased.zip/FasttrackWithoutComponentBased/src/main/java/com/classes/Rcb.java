package com.classes;

import com.interfaces.Ipl;

public class Rcb implements Ipl{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Rcb is team of Banglore");
		
	}
	

}

package com.si;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.classes.Csk;
import com.classes.Rcb;

@SpringBootApplication
public class FasttrackWithoutComponentBasedApplication {

	public static void main(String[] args) {
	
		Rcb r1=new Rcb();
		Csk c1=new Csk();
		r1.display();
		c1.display();
		
		
	}

}

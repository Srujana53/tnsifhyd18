package com.interfaces;

public interface Ipl {
	void display();

}

package assignments;

public class Approach1 {
	int age=20;
	static String name="Srujana";
	void display()
	{
		System.out.println("My age is:" +age);
	}
	static String display1()
	{
		return "My name is Srujana";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach1 a1=new Approach1();
		System.out.println(a1.age);
		a1.display();
		System.out.println(Approach1.name);
        System.out.println(display1());
	}

}

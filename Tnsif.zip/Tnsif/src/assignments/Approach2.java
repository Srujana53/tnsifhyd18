package assignments;

public class Approach2 {
    int stuid=101;
    static String stuname="Srujana Munagala";
    void display()
    {
    	System.out.println("studentid is:" +stuid);
    }
    static String show()
    {
    	return "Studentname is Srujana Munagala";
    }
    
}

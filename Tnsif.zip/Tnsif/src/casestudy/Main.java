package casestudy;
import vehicle.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike b=new Bike();
		Car c=new Car();
		Bus b1=new Bus();
		b.start();
		b.stop();
		b.speed();
		c.start();
		c.stop();
		c.speed();
		b1.start();
		b1.stop();
		b1.speed();
		


	}

}

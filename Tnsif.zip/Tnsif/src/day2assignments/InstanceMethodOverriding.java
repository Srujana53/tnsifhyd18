package day2assignments;

public class InstanceMethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent obj=new Child();
		obj.display();
		

	}

}

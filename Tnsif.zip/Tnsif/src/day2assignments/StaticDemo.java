package day2assignments;

public class StaticDemo {
	static int b=10;
	static void display()
	{
		System.out.println(b);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticDemo.display();
		
	}

}

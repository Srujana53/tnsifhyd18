package day2assignments;

public class InstanceStaticMethodsOverloading {
		void display()
		{
			System.out.println("display method");
		}
		int display(int a)
		{
			return a;
		}
		public static void show()
		{
			System.out.println("show method");
		}
		public static String show(String name)
		{
			return name;
		}
		
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InstanceStaticMethodsOverloading obj=new InstanceStaticMethodsOverloading();
		obj.display();
		System.out.println(obj.display(10));
		show();
		System.out.println(InstanceStaticMethodsOverloading.show("Srujana"));
		

}
}
package day2assignments;

public class StaticMethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Base obj=new Derived();
		obj.show();
  }
 
}

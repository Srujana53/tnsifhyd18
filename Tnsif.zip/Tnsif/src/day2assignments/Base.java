package day2assignments;

public class Base {
	 static void show()
	{
		System.out.println("This is Base class show() method");
	}

}

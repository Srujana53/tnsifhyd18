package vehicle;

public class Bike {
	public void start()
	{
		System.out.println("bike started");
	}
	public void stop()
	{
		System.out.println(" bike stopped");
	}
	public void speed()
	{
		System.out.println("Average speed of Bike is 30km/h");
	}

}

package day3assignments;

public class HierarchicalParent {
	void display()
	{
		System.out.println(" Parent Method");
	}

}

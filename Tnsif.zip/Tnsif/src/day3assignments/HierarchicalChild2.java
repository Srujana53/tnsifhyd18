package day3assignments;

public class HierarchicalChild2 extends HierarchicalParent{
	void print()
	{
		System.out.println("Child2 Method");
	}

}

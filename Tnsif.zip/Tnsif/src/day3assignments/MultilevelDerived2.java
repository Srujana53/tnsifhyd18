package day3assignments;

public class MultilevelDerived2 extends MultilevelDerived1{
	void print()
	{
		System.out.println("Derived2 Method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultilevelDerived2 obj=new MultilevelDerived2();
		obj.display();
		obj.show();
		obj.print();
		

		
	}

}

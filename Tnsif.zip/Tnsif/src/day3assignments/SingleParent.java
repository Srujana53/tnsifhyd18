package day3assignments;

public class SingleParent {
	void show()
	{
		System.out.println("Parent method");
	}

}

/**
 * 
 */
/**
 * 
 */
module Minorprojectjdbc {
	requires java.sql;
}
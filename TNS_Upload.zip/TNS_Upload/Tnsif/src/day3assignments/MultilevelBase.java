package day3assignments;

public class MultilevelBase {
 void display()
 {
	 System.out.println("Base Method");
 }
}

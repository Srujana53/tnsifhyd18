package day3assignments;

public class MultilevelDerived1 extends MultilevelBase{
	void show()
	 {
		 System.out.println("Derived1 method");
	 }
	}




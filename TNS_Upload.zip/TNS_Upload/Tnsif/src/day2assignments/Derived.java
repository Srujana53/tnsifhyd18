package day2assignments;

public class Derived extends Base{
	static void show()
	{
		System.out.println("This is Derived class show() method");
	}

     
	

}

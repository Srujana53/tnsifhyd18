package day2assignments;

public class InstanceDemo
{
static int a=10;
String name="Srujana";
void display()
{
	System.out.println(a);
	System.out.println(name);
}
public static void main(String[] args) {
	InstanceDemo obj=new InstanceDemo();
	obj.display();
	
}


}

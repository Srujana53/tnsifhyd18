package day2assignments;

public class Parent {
	void display()
	{
		System.out.println("This is Parent class");
	}
	
}

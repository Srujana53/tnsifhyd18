package day2assignments;

public class Child extends Parent{
	void display()
	{
		System.out.println("This is Child class");
	}
    
}

package vehicle;

public class Bus {
	public void start()
	{
		System.out.println("bus is started");
	}
	public void stop()
	{
		System.out.println(" bus is stopped");
	}
	public void speed()
	{
		System.out.println("Average speed of Bus is 60km/h");
	}

}

package assignments;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach2 a2=new Approach2();
		System.out.println(a2.stuid);
		a2.display();
		System.out.println(Approach2.stuname);
		System.out.println(Approach2.show());

	}

}

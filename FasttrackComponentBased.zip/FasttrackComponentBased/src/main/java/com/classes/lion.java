package com.classes;

import org.springframework.stereotype.Component;

import com.interfaces.Animal;

@Component("lion")
public class lion implements Animal{


	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Lion is Roaring");
		
	}

}

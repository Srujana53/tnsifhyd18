package com.classes;

import org.springframework.stereotype.Component;

import com.interfaces.Animal;

@Component("c1")
public class Cat implements Animal{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("cat sounds meow");
		
	}

}

package com.classes;

import org.springframework.stereotype.Component;

import com.interfaces.Animal;

@Component("dog")
public class Dog implements Animal{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Dog is Barking");
		
		
	}

	}



package com.interfaces;

public interface Animal 
{
  void show();
}

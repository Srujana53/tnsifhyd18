package com.si;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.reactive.HttpHandlerAutoConfiguration.AnnotationConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.interfaces.Animal;

@SpringBootApplication
public class FasttrackComponentBasedApplication {

	public static void main(String[] args) {
	   AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
	   Animal obj=context.getBean("lion",Animal.class);
	   obj.show();
	   context.close();
	}

}

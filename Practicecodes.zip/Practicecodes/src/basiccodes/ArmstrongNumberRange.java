package basiccodes;

public class ArmstrongNumberRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=1,n2=1000;
		for(int i=n1;i<=n2;i++)
		{
			int n=i,temp=i,sum=0,count=0,digit;
			
			while(n!=0)
			{
				n=n/10;
				count++;
			}
			n=temp;
			while(n!=0)
			{
				digit=n%10;
				sum+=Math.pow(digit,count);
				n=n/10;}
			if(sum==temp)
			{
				System.out.println(temp);
			}
		}

	}

}

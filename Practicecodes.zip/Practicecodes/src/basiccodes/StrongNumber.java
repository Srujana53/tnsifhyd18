package basiccodes;

public class StrongNumber {

	static int fact(int n)
	{
		if(n==0||n==1)
			return 1;
		else
			return n*fact(n -1);
		
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=345,digit,temp=n,sum=0;
		while(n!=0)
	
		{
			digit=n%10;
		
			sum+=fact(digit);
			n=n/10;
		}
		if(sum==temp)
		{
			System.out.println("Strong number");
		}
		else
		{
			System.out.print("Not a strong number");
		}
	}

}

package basiccodes;

public class HarshadsNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=47,sum=0,digit,temp=n;
		while(n!=0)
		{
			digit=n%10;
			sum+=digit;
			n=n/10;
		}
		if(temp%sum==0)
		{
			System.out.println("harshades number"); 
			
		}
		else
		{
			System.out.println("not Harshads ");
		}

	}

}

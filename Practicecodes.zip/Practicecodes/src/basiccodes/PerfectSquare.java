package basiccodes;

public class PerfectSquare {
	static boolean perfectsquare(int n)
	{    
		if(n>=0)                                   //     int n=87;
	{                                                       // int str=Math.sqrt(n);
		int s=(int)Math.sqrt(n);                              
		return ((s*s)==n);                                 //    if((str*str)==n)
		}                                                   // Sys("perfect")
		return false;                                            //else Sys("Not");
	}                                                     
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		           int n=89;
		           if(perfectsquare(n))
		           {
		        	 System.out.println("Perfect Square");  
		           }
		           else
		           {
		        	   System.out.println("Not Perfect Square");
		           }
		                                                  
	}

}

package basiccodes;

public class PrimenumberRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1=2,n2=50;
		for(int i=n1;i<=n2;i++)
		{
			boolean isprime=true;
			int n=i;
			if(n<=1)
				isprime=false;
			for(int j=2;j<=Math.sqrt(n);j++)
			{
				if(n%j==0)
				{
					isprime=false;
					break;
				}
			}
			if(isprime)
			{
				System.out.println(i);
			}
		}

	}

}

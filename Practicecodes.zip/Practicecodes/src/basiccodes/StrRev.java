package basiccodes;

import java.util.Scanner;

public class StrRev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a string:");
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String rev="";
		for(int i=str.length()-1;i>=0;i--)
		{
			rev+=str.charAt(i);
		}
		System.out.print(rev);
	
	

	}

}

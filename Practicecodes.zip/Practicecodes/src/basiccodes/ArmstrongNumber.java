package basiccodes;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

		 System.out.print("Enter a number: "); 
		int n = scanner.nextInt();
		int temp=n,count=0,digit,sum=0;
		while(n!=0)
		{
			n=n/10;
			count++;
		}
		n=temp;
		while(n!=0)
		{
			digit=n%10;
			sum+=Math.pow(digit,count);
			n=n/10;
		}
		if (temp==sum)
		 System.out.println(temp + " is an Armstrong number."); 
		else System.out.println(temp + " is not an Armstrong number.");

		   }

}

package basiccodes;

public class PowerofNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int base=2,exp=3,res=1;
		while(exp!=0)
		{
			res*=base;
			exp--;
		}
		System.out.println(res);
		/*int base=2,exp=3;
	    int power=(int) Math.pow(base,exp);
	    System.out.println(power);*/
	    

	}

}

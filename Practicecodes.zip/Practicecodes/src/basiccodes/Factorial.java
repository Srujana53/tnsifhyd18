package basiccodes;

public class Factorial {
	static int  fact(int n)
	{
		if(n==0||n==1)
			return 1;
		else
			return n*fact(n-1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int result=fact(6);
		System.out.println(result);
		/*for(int i=1;i<=5;i++)
		{
			fact*=i;
		}
		System.out.println(fact);*/

	}

}

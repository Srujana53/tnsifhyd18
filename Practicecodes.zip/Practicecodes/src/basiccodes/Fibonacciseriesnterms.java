package basiccodes;

public class Fibonacciseriesnterms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=8;
		int a=0,b=1;
		for(int i=1;i<=n;i++)
		{
			System.out.print(a+ " ");
			int c=a+b;
			a=b;
			b=c;
		}
		

	}

}

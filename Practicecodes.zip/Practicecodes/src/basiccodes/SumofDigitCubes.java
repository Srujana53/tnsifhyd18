package basiccodes;

public class SumofDigitCubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=124,digit,sum=0;
		while(n!=0)
		{
			digit=n%10;
			sum+=Math.pow(digit,3);
			n=n/10;
		}
       System.out.println(sum);
	}

}

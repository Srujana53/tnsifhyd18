package basiccodes;

public class AutomorphicNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=76;
		int sq=n*n;
		if(n%10==sq%10)
			System.out.println("Automorphic nmber");
		else
			System.out.println("not Automorphic number");
	}

}

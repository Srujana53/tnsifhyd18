/**
 * 
 */
/**
 * 
 */
module Practicecodes {
}
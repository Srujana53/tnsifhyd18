package com.sriindu.runningthreads;

public class ChildClass1 extends Thread {
	
	@Override
	public void run() {
		System.out.println("Run method of first class");
	}

}




